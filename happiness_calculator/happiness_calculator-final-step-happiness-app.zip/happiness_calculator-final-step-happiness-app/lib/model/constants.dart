import 'package:flutter/material.dart';

const inactiveColor = Colors.amber;
const activeColor = Colors.red;
