# Happiness Calculator is a Flutter App that we will build step by step
### Besides, as usual we will learn some new technique to boost our knowledge

## I share my learning experience on Flutter, Dart, and Algorithm in - [https://sanjibsinha.com](https://sanjibsinha.com)

![Beginner](https://user-images.githubusercontent.com/3192445/156914934-6ae6b514-3a3f-4a48-af30-7c06a223d8fb.jpg)


There are lot of tips and tricks that might be useful for beginners. 

## Getting Started

The website - [https://sanjibsinha.com](https://sanjibsinha.com) is a project, which is a starting point for a WordPress application. Any beginner may use the code repository to learn how one can develop a WordPress web application from scratch.

- [Lab: Read the Latest Updated Articles on Flutter Tool Kit](https://sanjibsinha.com/category/flutter)


## Have you not coded before?
Well, we have a commonness. We all started, as non-coders who had not coded before.
In that case, you may read these Books to build Flutter App from scratch.
### In English
- [Elementary Dart and Flutter for Beginners](https://leanpub.com/elementarydartandflutterforbeginners)
### In French
- [Dart et Flutter pour les Débutants](https://leanpub.com/dartetflutterpourlesdbutants)


## Get the necessary Guide


- [Beginning Flutter with Dart](https://leanpub.com/beginningflutterwithdart)
- [Better Flutter](https://leanpub.com/betterflutter)
- [State in Flutter](https://leanpub.com/stateinflutter)
- [A Complete Flutter Guide: From Beginners to Advanced](https://leanpub.com/b/acompleteflutterguidefrombeginnerstoadvanced)


## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

A few resources to get you started if this is your first WordPress project:

- [Download the latest WordPres](https://wordpress.org)
- [Then start building a WordPress sample app like this:](https://sanjibsinha.com)
