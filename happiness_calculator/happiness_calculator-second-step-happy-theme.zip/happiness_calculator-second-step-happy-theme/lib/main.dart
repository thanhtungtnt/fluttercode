import 'package:flutter/material.dart';

import 'view/happiness_app.dart';

// this is a new branch enum and color change

void main() {
  runApp(const HappinessApp());
}
