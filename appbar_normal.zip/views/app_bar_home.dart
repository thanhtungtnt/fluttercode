import 'package:flutter/material.dart';
import 'app_bar_next.dart';

class AppBarHome extends StatelessWidget {
  const AppBarHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Appbar Example'),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.add_alert),
            tooltip: 'Show Snackbar',
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('A Snackbar'),
                ),
              );
            },
          ),
          IconButton(
              icon: const Icon(Icons.search_outlined),
              tooltip: 'Search',
              onPressed: () {
                //our code
              }),
          IconButton(
            icon: const Icon(Icons.navigate_next),
            tooltip: 'Next page',
            onPressed: () {
              Navigator.push(context, MaterialPageRoute<void>(
                builder: (BuildContext context) {
                  return const AppBarNext();
                },
              ));
            },
          ),
        ],
      ),
      body: const Center(
        child: Text(
          'This is the AppBar Example home page',
          style: TextStyle(fontSize: 30),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
