import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Sliver AppBar Sample App',
      debugShowCheckedModeBanner: false,
      home: SliverAppBarHome(),
    );
  }
}

class SliverAppBarHome extends StatelessWidget {
  const SliverAppBarHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: CustomScrollView(
      slivers: [
        SliverAppBar(
          expandedHeight: 300.0,
          floating: false,
          pinned: true,
          flexibleSpace: FlexibleSpaceBar(
            centerTitle: true,
            title: const Text(
              'It will collapse',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
            background: Image.network('https://picsum.photos/400/200',
                fit: BoxFit.cover),
          ),
        ),
        SliverFixedExtentList(
          itemExtent: 50,
          delegate: SliverChildListDelegate([
            Container(color: Colors.red),
            Container(color: Colors.green),
            Container(color: Colors.blue),
            Container(color: Colors.red),
            Container(color: Colors.green),
            Container(color: Colors.blue),
            Container(color: Colors.red),
            Container(color: Colors.green),
            Container(color: Colors.blue),
          ]),
        )
      ],
    ));
  }
}//end SliverAppBarHome