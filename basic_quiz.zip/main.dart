import 'package:flutter/material.dart';
import 'questions.dart';
import 'answers.dart';

void main() {
  runApp(const QuizApp());
}

class QuizApp extends StatelessWidget {
  const QuizApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Playxis - Play + Lexis',
      debugShowCheckedModeBanner: false,
      home: QuizPage(),
    );
  }
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int index = 0;
  void increment() {
    setState(() {
      index = index + 1;
    });
    if (index == questions.length) {
      index = 0;
    }
  }

  var questions = [
    {
      'question': 'Who are you?',
      'answer': [
        'Robot',
        'Human',
        'Alien',
      ],
    },
    {
      'question': 'What is your name?',
      'answer': [
        'Robu',
        'Honu',
        'Alu',
      ],
    },
    {
      'question': 'What do you eat?',
      'answer': [
        'Electricity',
        'Everything',
        'Water of Mars',
      ],
    },
    {
      'question': 'What do you want?',
      'answer': [
        'Follow the instruction',
        'Go to war and destroy.',
        'Go back to Mars.',
      ],
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: const Text(
          'Playxis - Play + Lexis',
        )),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Question(questions: questions, index: index),
              //Cach viet map trong flutter
              ...(questions[index]['answer'] as List<String>).map(
                (answer) {
                  return Answer(
                    answer: answer,
                    pointToOnPress: increment,
                  );
                },
              ).toList(),
            ],
          ),
        ));
  }
}
