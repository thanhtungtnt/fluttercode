import 'package:flutter/material.dart';

class FirstColumn extends StatelessWidget{
  const FirstColumn({super.key});

  @override
  Widget build(BuildContext context){
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.network(
          'https://picsum.photos/id/237/200/300',
          width: 120,
          height:100,
        ),
        Container(
            padding: const EdgeInsets.all(7),
            child: const Text(
                'Let\'s go',
                style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.white
                )
            )
        )
      ],
    );
  }
}

class SecondColumn extends StatelessWidget{
  const SecondColumn({super.key});

  @override
  Widget build(BuildContext context){
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.network(
            'https://picsum.photos/seed/picsum/200/300',
            width:120,
            height:100
        ),
        Container(
            padding: const EdgeInsets.all(7),
            child: const Text(
              'Let\'s go',
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
              ),
            )
        )
      ],
    );
  }
}

class ThirdColumn extends StatelessWidget{
  const ThirdColumn({super.key});

  @override
  Widget build(BuildContext context){
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.network(
          'https://picsum.photos/200/300',
          width: 120,
          height:100,
        ),
        Container(
            padding: const EdgeInsets.all(7),
            child: const Text(
              'Let\'s go',
              style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue
              ),
            )
        )
      ],
    );
  }
}
