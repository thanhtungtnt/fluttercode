import 'package:flutter/material.dart';
import 'all_pages.dart';

TabBar allTabBars() => TabBar(
      isScrollable: true,
      indicatorColor: Colors.white,
      indicatorWeight: 2,
      tabs: [
        Tab(
          icon: Icon(Icons.home),
          text: 'Home',
        ),
        Tab(
          icon: Icon(Icons.account_box),
          text: 'Log in',
        ),
        Tab(
          icon: Icon(Icons.security),
          text: 'Account',
        ),
        Tab(
          icon: Icon(Icons.settings),
          text: 'Settings',
        ),
      ],
    );

TabBarView allTabBarViews(size) => TabBarView(
      children: [
        FirstPage(size: size),
        SecondPage(size: size),
        ThirdPage(size: size),
        FourPage(size: size),
      ],
    );
