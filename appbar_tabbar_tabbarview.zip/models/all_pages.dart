import 'package:flutter/material.dart';

class FirstPage extends StatelessWidget {
  const FirstPage({super.key, required Size size});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'First Page',
        style: const TextStyle(
          fontSize: 60,
          fontWeight: FontWeight.bold,
          color: Colors.red,
        ),
      ),
    );
  }
}

class SecondPage extends StatelessWidget {
  const SecondPage({super.key, required Size size});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Second Page',
        style: const TextStyle(
          fontSize: 60,
          fontWeight: FontWeight.bold,
          color: Colors.red,
        ),
      ),
    );
  }
}

class ThirdPage extends StatelessWidget {
  const ThirdPage({super.key, required Size size});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Third Page',
        style: const TextStyle(
          fontSize: 60,
          fontWeight: FontWeight.bold,
          color: Colors.red,
        ),
      ),
    );
  }
}

class FourPage extends StatelessWidget {
  const FourPage({super.key, required Size size});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Four Page',
        style: const TextStyle(
          fontSize: 60,
          fontWeight: FontWeight.bold,
          color: Colors.red,
        ),
      ),
    );
  }
}
