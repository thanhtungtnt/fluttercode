import 'package:flutter/material.dart';
import 'dash_board_home.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'A Custom Home Page',
      debugShowCheckedModeBanner: false,
      home: DashBoardHome(),
    );
  }
}
