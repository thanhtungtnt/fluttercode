import 'package:flutter/material.dart';
import '../models/shaping_painter.dart';
import '../models/all_containers.dart';

class DashBoardHome extends StatelessWidget {
  const DashBoardHome({super.key});

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                  colors: [Colors.pink, Colors.blue],
                  begin: Alignment.topRight,
                  end: Alignment.bottomRight),
            ),
          ),
          elevation: 50,
          leading: const Icon(Icons.menu),
          title: const Text(
            'Let\'s Go',
            textAlign: TextAlign.center,
          ),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.run_circle)),
            IconButton(
                onPressed: () {}, icon: const Icon(Icons.notification_add)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          ],
          bottom: TabBar(
            tabs: [
              Tab(
                icon: IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.home),
                ),
                text: 'Home',
              ),
              Tab(
                icon: IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.account_box),
                ),
                text: 'Log in',
              ),
              Tab(
                icon: IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.security),
                ),
                text: 'Account',
              ),
              Tab(
                icon: IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.home),
                ),
                text: 'Settings',
              ),
            ],
          ),
        ),
        body: Stack(children: <Widget>[
          Container(
            padding: const EdgeInsets.all(5),
            child: CustomPaint(
                painter: ShapingPainter(),
                child: Container(height: size.height / 1)),
          ),
          ListView(children: const [
            FirstContainer(),
            SecondContainer(),
            ThirdContainer()
          ])
        ]),
      ),
    );
  }
}
