import 'package:flutter/material.dart';

import 'all_coumns.dart';

class FirstContainer extends StatelessWidget{
  const FirstContainer({super.key});

  @override
  Widget build(BuildContext context){
    return Container(
      margin: const EdgeInsets.all(10),
      child: Row(
          children: const [
            FirstColumn(),
            SecondColumn(),
            ThirdColumn()
          ],
      ),
    );
  }
}

class SecondContainer extends StatelessWidget{
  const SecondContainer({super.key});

  @override
  Widget build(BuildContext context){
    return Container(
      margin: const EdgeInsets.all(10),
      child: Row(
        children: const [
          FirstColumn(),
          SecondColumn(),
          ThirdColumn()
        ],
      ),
    );
  }
}

class ThirdContainer extends StatelessWidget{
  const ThirdContainer({super.key});

  @override
  Widget build(BuildContext context){
    return Container(
      margin: const EdgeInsets.all(10),
      child: Row(
        children: const [
          FirstColumn(),
          SecondColumn(),
          ThirdColumn()
        ],
      ),
    );
  }
}