import 'package:flutter/material.dart';

class DashBoardHome extends StatelessWidget {
  const DashBoardHome({super.key});

  @override
  Widget build(BuildContext context) {
    // var size = MediaQuery.of(context).size;

    return DefaultTabController(
        length: 4,
        child: Scaffold(
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            title: const Text('Testing Transparency'),
            centerTitle: true,
            leading: const BackButton(
              color: Colors.white,
            ),
            actions: [
              IconButton(
                  onPressed: () {}, icon: const Icon(Icons.holiday_village)),
            ],
            shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(10),
            )),
            backgroundColor: Colors.white.withOpacity(0.19),
            elevation: 0,
          ),
          body: Image.network(
            'https://picsum.photos/800/800',
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
          ),
        ));
  }

  IconButton buildIcons(Icon iconvalue) {
    return IconButton(
      onPressed: () {},
      icon: iconvalue,
    );
  }
}//end class